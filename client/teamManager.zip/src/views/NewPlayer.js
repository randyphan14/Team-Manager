import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';
import PlayerForm from '../components/PlayerForm'

export default props => {
    // const [player, setPlayer] = useState([]);
    // const [loaded, setLoaded] = useState(false);
    // const [errors, setErrors] = useState([]); 
    // useEffect(() => {
    //     axios.get('http://localhost:8000/api/player')
    //         .then(res =>{ 
    //             setPlayer(res.data);
    //             setLoaded(true);
    //         });
    //     }, [])
        
    //     const createPlayer = person => {
    //         axios.post('http://localhost:8000/api/player', person)
    //         .then(res=>{
    //             setPlayer([...player, res.data]);
    //             navigate('/players/list');
    //         })
    //         .catch(err=>{
    //             const errorResponse = err.response.data.errors; // Get the errors from err.response.data
    //             const errorArr = []; // Define a temp error array to push the messages in
    //             for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
    //                 errorArr.push(errorResponse[key].message)
    //             }
    //             // Set Errors
    //             setErrors(errorArr);
    //         })
    // }

    return (
        <div>
            <h2>Manage Players | <Link to= {"/status/game/1"}>Manage Player Status</Link></h2>
            <hr/>
            <h1><Link to={"/players/list"}>List</Link> | Add Player</h1>
            <hr/>
            <h3>Add Player</h3>
            {/* {errors.map((err, index) => <p key={index}>{err}</p>)} */}
            <PlayerForm initialName="" initialPosition=""/>
            {/* <PlayerForm onSubmitProp={createPlayer} initialName="" initialPosition=""/> */}
        </div>
    )
}
